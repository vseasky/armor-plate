#include "string.h"
#include "stdlib.h"
#include "bsp_dbus.h"
//DBUSң����
RC_Ctrl_t RC_CtrlData;
uint8_t SBUS_rx_buf[2][SBUS_RX_BUF_NUM];
const RC_Ctrl_t* get_rc_ctrl_info_data(void)
{
    return &RC_CtrlData;
}
void Dbus_Online_Check(void)
{
    RC_CtrlData.real_online_flag = RC_CtrlData.online_flag;
}
void Dbus_Clear_Online_flag(void)
{
    RC_CtrlData.online_flag=0;
}
void DbusDataProcess(RC_Ctrl_t *RC_CtrlData, uint8_t *pData)
{
    if(pData==NULL)
        {
            return;
        }
    RC_CtrlData->rc.ch0=(pData[0] | pData[1] << 8)&0x07FF;
    RC_CtrlData->rc.ch0 -=1024;
    RC_CtrlData->rc.ch1=(pData[1] >> 3 | pData[2] << 5)&0x07FF;
    RC_CtrlData->rc.ch1 -=1024;
    RC_CtrlData->rc.ch2=(pData[2] >> 6 | pData[3] << 2 | pData[4] << 10)&0x07FF;
    RC_CtrlData->rc.ch2 -=1024;
    RC_CtrlData->rc.ch3=(pData[4] >> 1 | pData[5] << 7)&0x07FF;
    RC_CtrlData->rc.ch3 -=1024;
    RC_CtrlData->rc.s1=((pData[5] >> 4)&0x000C) >> 2;
    RC_CtrlData->rc.s2=((pData[5] >> 4)&0x0003);

    RC_CtrlData->mouse.x=(pData[6] | pData[7] << 8);
    RC_CtrlData->mouse.y=(pData[8] | pData[9] << 8);
    RC_CtrlData->mouse.z=(pData[10] | pData[11] << 8);
    RC_CtrlData->mouse.press_l=pData[12];
    RC_CtrlData->mouse.press_r=pData[13];

    RC_CtrlData->keyboard.key_code= pData[14] | (pData[15] << 8);
    RC_CtrlData->wheel = (pData[16] | pData[17] << 8) - 1024;
}
void mx_dbus_init(void)
{
    /* -------------- Enable Module Clock Source ----------------------------*/
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_UART4); //PA1  uart4 rx
    /* -------------- Configure GPIO ---------------------------------------*/
    {
        GPIO_InitTypeDef GPIO_InitStructure;
        USART_InitTypeDef USART_InitStructure;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
        GPIO_Init(GPIOA, &GPIO_InitStructure);

        USART_DeInit(UART4);

        USART_InitStructure.USART_BaudRate = 100000;
        USART_InitStructure.USART_WordLength = USART_WordLength_8b;
        USART_InitStructure.USART_StopBits = USART_StopBits_1;
        USART_InitStructure.USART_Parity = USART_Parity_Even;
        USART_InitStructure.USART_Mode = USART_Mode_Rx;
        USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
        USART_Init(UART4, &USART_InitStructure);

        USART_DMACmd(UART4, USART_DMAReq_Rx, ENABLE);

        USART_ClearFlag(UART4, USART_FLAG_IDLE);
        USART_ITConfig(UART4, USART_IT_IDLE, ENABLE);

        USART_Cmd(UART4, ENABLE);
    }

    /* -------------- Configure NVIC ---------------------------------------*/
    {
        NVIC_InitTypeDef NVIC_InitStructure;
        NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
        NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
        NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
        NVIC_Init(&NVIC_InitStructure);
    }

    //DMA1 stream2 ch4  !!!!!!! P206 of the datasheet
    /* -------------- Configure DMA -----------------------------------------*/
    {
        DMA_InitTypeDef DMA_InitStructure;
        DMA_DeInit(DMA1_Stream2);

        DMA_InitStructure.DMA_Channel = DMA_Channel_4;
        DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t) & (UART4->DR);
        DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)SBUS_rx_buf[0];
        DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
        DMA_InitStructure.DMA_BufferSize = SBUS_RX_BUF_NUM;
        DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
        DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
        DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
        DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
        DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
        DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
        DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
        DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_1QuarterFull;
        DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
        DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;
        DMA_Init(DMA1_Stream2, &DMA_InitStructure);
        DMA_DoubleBufferModeConfig(DMA1_Stream2, (uint32_t)SBUS_rx_buf[1], DMA_Memory_0);
        DMA_DoubleBufferModeCmd(DMA1_Stream2, ENABLE);
        DMA_Cmd(DMA1_Stream2, DISABLE); //Add a disable
        DMA_Cmd(DMA1_Stream2, ENABLE);
    }
}
void RC_unable(void)
{
    USART_Cmd(UART4, DISABLE);
}
void RC_restart(uint16_t dma_buf_num)
{
    USART_Cmd(UART4, DISABLE);
    DMA_Cmd(DMA1_Stream2, DISABLE);
    DMA_SetCurrDataCounter(DMA1_Stream2, dma_buf_num);

    USART_ClearFlag(UART4, USART_FLAG_IDLE);

    DMA_ClearFlag(DMA1_Stream2, DMA_FLAG_TCIF2);
    DMA_ClearITPendingBit(DMA1_Stream2, DMA_IT_TCIF2);
    DMA_Cmd(DMA1_Stream2, ENABLE);
    USART_Cmd(UART4, ENABLE);
}
void UART4_IRQHandler(void)
{
    static uint32_t this_time_rx_len = 0;
    if (USART_GetITStatus(UART4, USART_IT_IDLE) != RESET)
        {
            USART_ReceiveData(UART4);
            RC_CtrlData.online_flag=1;
            RC_CtrlData.online_flag=1;
            if(DMA_GetCurrentMemoryTarget(DMA1_Stream2) == 0)
                {
                    DMA_Cmd(DMA1_Stream2, DISABLE);
                    this_time_rx_len = SBUS_RX_BUF_NUM - DMA_GetCurrDataCounter(DMA1_Stream2);
                    DMA1_Stream2->NDTR = (uint16_t)SBUS_RX_BUF_NUM;
                    DMA1_Stream2->CR |= (uint32_t)(DMA_SxCR_CT);
                    DMA_Cmd(DMA1_Stream2, ENABLE);
                    if(this_time_rx_len == RC_FRAME_LENGTH)
                        {
                            DbusDataProcess(&RC_CtrlData,SBUS_rx_buf[0]);
                        }
                }
            else
                {
                    DMA_Cmd(DMA1_Stream2, DISABLE);
                    this_time_rx_len = SBUS_RX_BUF_NUM - DMA_GetCurrDataCounter(DMA1_Stream2);
                    DMA1_Stream2->NDTR = (uint16_t)SBUS_RX_BUF_NUM;
                    DMA1_Stream2->CR |= (uint32_t)(DMA_SxCR_CT);
                    DMA_Cmd(DMA1_Stream2, ENABLE);
                    if(this_time_rx_len == RC_FRAME_LENGTH)
                        {
                            DbusDataProcess(&RC_CtrlData,SBUS_rx_buf[1]);
                        }
                }
        }
}
