#ifndef _BSP_USART6_H
#define _BSP_USART6_H
#include "stm32f4xx_usart.h"


void mx_usart6_init(void);
void usart6_send(uint8_t *data,uint16_t len);



#endif
