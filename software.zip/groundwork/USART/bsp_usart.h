#ifndef __BSP_USART_H
#define __BSP_USART_H
#include "stm32f4xx.h"

void mx_usart1_init(void);
void mx_usart2_init(void);
void mx_usart3_init(void);
void mx_usart6_init(void);
void mx_uart7_init(void);
void mx_uart8_init(void);
void usart_send(USART_TypeDef* USARTx,uint8_t *data,uint16_t len);
#endif
