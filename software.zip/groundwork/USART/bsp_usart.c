#include "bsp_usart.h"
uint8_t text[16] = "hello world \r\n";
void mx_usart1_init(void)
{
    //USART1_RX/PA10
    //USART1_TX/PA9
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);

    GPIO_PinAFConfig(GPIOA,GPIO_PinSource9,GPIO_AF_USART1);
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource10,GPIO_AF_USART1);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate=115200;
    USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_Parity=USART_Parity_No;
    USART_InitStructure.USART_StopBits=USART_StopBits_1;
    USART_InitStructure.USART_WordLength=USART_WordLength_8b;
    USART_Init(USART1,&USART_InitStructure);
    USART_Cmd(USART1,ENABLE);

    USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel=USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
    NVIC_Init(&NVIC_InitStructure);

    usart_send(USART1,text,16);

}

void mx_usart2_init(void)
{
    //USART2_RX/PD6
    //USART2_TX/PD5
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);

    GPIO_PinAFConfig(GPIOD,GPIO_PinSource5,GPIO_AF_USART2);
    GPIO_PinAFConfig(GPIOD,GPIO_PinSource6,GPIO_AF_USART2);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate=115200;
    USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_Parity=USART_Parity_No;
    USART_InitStructure.USART_StopBits=USART_StopBits_1;
    USART_InitStructure.USART_WordLength=USART_WordLength_8b;
    USART_Init(USART2,&USART_InitStructure);
    USART_Cmd(USART2,ENABLE);

    USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel=USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
    NVIC_Init(&NVIC_InitStructure);

    usart_send(USART2,text,16);
}
void mx_usart3_init(void)
{
    //USART3_RX/PD9
    //USART3_TX/PD8
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);

    GPIO_PinAFConfig(GPIOD,GPIO_PinSource8,GPIO_AF_USART3);
    GPIO_PinAFConfig(GPIOD,GPIO_PinSource9,GPIO_AF_USART3);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate=115200;
    USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_Parity=USART_Parity_No;
    USART_InitStructure.USART_StopBits=USART_StopBits_1;
    USART_InitStructure.USART_WordLength=USART_WordLength_8b;
    USART_Init(USART3,&USART_InitStructure);
    USART_Cmd(USART3,ENABLE);

    USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel=USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
    NVIC_Init(&NVIC_InitStructure);


    usart_send(USART3,text,16);
}

void mx_usart6_init(void)
{
    //USART6_RX/PC7
    //USART6_TX/PC6
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6,ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);

    GPIO_PinAFConfig(GPIOC,GPIO_PinSource6,GPIO_AF_USART6);
    GPIO_PinAFConfig(GPIOC,GPIO_PinSource7,GPIO_AF_USART6);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate=115200;
    USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_Parity=USART_Parity_No;
    USART_InitStructure.USART_StopBits=USART_StopBits_1;
    USART_InitStructure.USART_WordLength=USART_WordLength_8b;
    USART_Init(USART6,&USART_InitStructure);
    USART_Cmd(USART6,ENABLE);

    USART_ITConfig(USART6,USART_IT_RXNE,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel=USART6_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
    NVIC_Init(&NVIC_InitStructure);

    usart_send(USART6,text,16);

}
void mx_uart7_init(void)
{
    //UART7_RX/PE7
    //UART7_TX/PE8
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART7,ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);

    GPIO_PinAFConfig(GPIOE,GPIO_PinSource7,GPIO_AF_UART7);
    GPIO_PinAFConfig(GPIOE,GPIO_PinSource8,GPIO_AF_UART7);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7|GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate=115200;
    USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_Parity=USART_Parity_No;
    USART_InitStructure.USART_StopBits=USART_StopBits_1;
    USART_InitStructure.USART_WordLength=USART_WordLength_8b;
    USART_Init(UART7,&USART_InitStructure);
    USART_Cmd(UART7,ENABLE);

    USART_ITConfig(UART7,USART_IT_RXNE,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel=UART7_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
    NVIC_Init(&NVIC_InitStructure);

    usart_send(UART7,text,16);
}
void mx_uart8_init(void)
{
    //UART8_RX/PE0
    //UART8_TX/PE1
    USART_InitTypeDef USART_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART8,ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);

    GPIO_PinAFConfig(GPIOE,GPIO_PinSource0,GPIO_AF_UART8);
    GPIO_PinAFConfig(GPIOE,GPIO_PinSource1,GPIO_AF_UART8);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate=115200;
    USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_Parity=USART_Parity_No;
    USART_InitStructure.USART_StopBits=USART_StopBits_1;
    USART_InitStructure.USART_WordLength=USART_WordLength_8b;
    USART_Init(UART8,&USART_InitStructure);
    USART_Cmd(UART8,ENABLE);

    USART_ITConfig(UART8,USART_IT_RXNE,ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel=UART8_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
    NVIC_Init(&NVIC_InitStructure);
    usart_send(UART8,text,16);
}
void usart_send(USART_TypeDef* USARTx,uint8_t *data,uint16_t len)
{
    for(uint16_t i=0; i<len; i++)
        {
            while((USARTx->SR&USART_FLAG_TC)==0);//�������
            USART_SendData(USARTx,data[i]);
        }
}

//USART1�����ж�
void USART1_IRQHandler(void)
{
	u8 temp;
    if(USART_GetITStatus(USART1, USART_IT_ORE_RX) != RESET)
    {
        USART_ReceiveData(USART1); 
    }
    else if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        USART_ClearFlag(USART1, USART_FLAG_RXNE);       
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
        temp = USART_ReceiveData(USART1);
    }
}

//USART2�����ж�
void USART2_IRQHandler(void)
{
	u8 temp;
    if(USART_GetITStatus(USART2, USART_IT_ORE_RX) != RESET)
    {
        USART_ReceiveData(USART2); 
    }
    else if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
    {
        USART_ClearFlag(USART2, USART_FLAG_RXNE);       
        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
        temp = USART_ReceiveData(USART2);
    }
}

//USART3�����ж�
void USART3_IRQHandler(void)
{
	u8 temp;
    if(USART_GetITStatus(USART3, USART_IT_ORE_RX) != RESET)
    {
        USART_ReceiveData(USART3); 
    }
    else if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
    {
        USART_ClearFlag(USART3, USART_FLAG_RXNE);       
        USART_ClearITPendingBit(USART3, USART_IT_RXNE);
        temp = USART_ReceiveData(USART3);
    }
}

//USART6�����ж�
void USART6_IRQHandler(void)
{
	u8 temp;
    if(USART_GetITStatus(USART6, USART_IT_ORE_RX) != RESET)
    {
        USART_ReceiveData(USART6); 
    }
    else if(USART_GetITStatus(USART6, USART_IT_RXNE) != RESET)
    {
        USART_ClearFlag(USART6, USART_FLAG_RXNE);       
        USART_ClearITPendingBit(USART6, USART_IT_RXNE);
        temp = USART_ReceiveData(USART6);
    }
}

//UART7�����ж�
void UART7_IRQHandler(void)
{
	u8 temp;
    if(USART_GetITStatus(UART7, USART_IT_ORE_RX) != RESET)
    {
        USART_ReceiveData(UART7); 
    }
    else if(USART_GetITStatus(UART7, USART_IT_RXNE) != RESET)
    {
        USART_ClearFlag(UART7, USART_FLAG_RXNE);       
        USART_ClearITPendingBit(UART7, USART_IT_RXNE);
        temp = USART_ReceiveData(UART7);
    }
}

//UART7�����ж�
void UART8_IRQHandler(void)
{
	u8 temp;
    if(USART_GetITStatus(UART8, USART_IT_ORE_RX) != RESET)
    {
        USART_ReceiveData(UART8); 
    }
    else if(USART_GetITStatus(UART8, USART_IT_RXNE) != RESET)
    {
        USART_ClearFlag(UART8, USART_FLAG_RXNE);       
        USART_ClearITPendingBit(UART8, USART_IT_RXNE);
        temp = USART_ReceiveData(UART8);
    }
}