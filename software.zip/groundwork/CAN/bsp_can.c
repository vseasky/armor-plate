#include "bsp_can.h"

total_info motor_feedback;

//利用指针传递数据
const total_info* get_motor_info_data(void)
{
    motor_feedback.moto_info_gm6020[0].offset_angle_get=0;
    motor_feedback.moto_info_gm6020[0].angle=0;
    motor_feedback.moto_info_gm6020[0].offset_angle=0;
    motor_feedback.moto_info_gm6020[0].default_zero_angle = DEFAULT_ANGLE_YAW;

    motor_feedback.moto_info_gm6020[1].angle=0;
    motor_feedback.moto_info_gm6020[1].offset_angle_get=0;
    motor_feedback.moto_info_gm6020[1].offset_angle=0;
    motor_feedback.moto_info_gm6020[1].default_zero_angle = DEFAULT_ANGLE_PITCH;

    return &motor_feedback;
}
//波特率 ->1MHZ
void mx_can1_init(void)
{
	//PCLK1_Frequency = 42000000->42M
	//CAN1_TX/PD1
	//CAN1_RX/PD0
    GPIO_InitTypeDef GPIO_InitStructure;
    CAN_InitTypeDef CAN_InitStructure;
    CAN_FilterInitTypeDef CAN_FilterInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

    RCC_APB1PeriphResetCmd(RCC_APB1Periph_CAN1, ENABLE);
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_CAN1, DISABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOD, GPIO_PinSource0, GPIO_AF_CAN1);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource1, GPIO_AF_CAN1);

    CAN_InitStructure.CAN_TTCM = DISABLE;
    CAN_InitStructure.CAN_ABOM = ENABLE;
    CAN_InitStructure.CAN_AWUM = DISABLE;
    CAN_InitStructure.CAN_NART = DISABLE;
    CAN_InitStructure.CAN_RFLM = DISABLE;
    CAN_InitStructure.CAN_TXFP = DISABLE;
    CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;
    CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;
    CAN_InitStructure.CAN_BS1 = CAN_BS1_5tq;
    CAN_InitStructure.CAN_BS2 = CAN_BS2_1tq;
    CAN_InitStructure.CAN_Prescaler = 6;
    CAN_Init(CAN1, &CAN_InitStructure);

    CAN_FilterInitStructure.CAN_FilterNumber = 0;
    CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
    CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
    CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;
    CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;
    CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;
    CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
    CAN_FilterInitStructure.CAN_FilterFIFOAssignment = CAN_Filter_FIFO0;
    CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
    CAN_FilterInit(&CAN_FilterInitStructure);

    CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

//波特率 ->1MHZ
void mx_can2_init(void)
{
	////PCLK1_Frequency = 42000000->42M
	//CAN2_TX/PB6
	//CAN2_RX/PB5
    GPIO_InitTypeDef GPIO_InitStructure;
    CAN_InitTypeDef CAN_InitStructure;
    CAN_FilterInitTypeDef CAN_FilterInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);

    RCC_APB1PeriphResetCmd(RCC_APB1Periph_CAN2, ENABLE);
    RCC_APB1PeriphResetCmd(RCC_APB1Periph_CAN2, DISABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource5, GPIO_AF_CAN2);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_CAN2);

    CAN_InitStructure.CAN_TTCM = DISABLE;
    CAN_InitStructure.CAN_ABOM = ENABLE;
    CAN_InitStructure.CAN_AWUM = DISABLE;
    CAN_InitStructure.CAN_NART = DISABLE;
    CAN_InitStructure.CAN_RFLM = DISABLE;
    CAN_InitStructure.CAN_TXFP = DISABLE;
    CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;
    CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;
    CAN_InitStructure.CAN_BS1 = CAN_BS1_5tq;
    CAN_InitStructure.CAN_BS2 = CAN_BS2_1tq;
    CAN_InitStructure.CAN_Prescaler = 6;
    CAN_Init(CAN2, &CAN_InitStructure);

    CAN_FilterInitStructure.CAN_FilterNumber = 14;
    CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;
    CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;
    CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;
    CAN_FilterInitStructure.CAN_FilterIdLow =  0x0000;
    CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;
    CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;
    CAN_FilterInitStructure.CAN_FilterFIFOAssignment = CAN_Filter_FIFO0;
    CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;
    CAN_FilterInit(&CAN_FilterInitStructure);

    CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = CAN2_RX0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
/*设定M3508电流*/
void set_m3508_current(s16 mt1,s16 mt2,s16 mt3,s16 mt4)
{
    CanTxMsg TxMessage;
    TxMessage.StdId= CAN_Tx_3508Moto_1_4;
    TxMessage.IDE = 0;
    TxMessage.RTR = 0;
    TxMessage.DLC = 8;
    TxMessage.Data[0] = mt1 >> 8;
    TxMessage.Data[1] = mt1;
    TxMessage.Data[2] = mt2 >> 8;
    TxMessage.Data[3] = mt2;
    TxMessage.Data[4] = mt3 >> 8;
    TxMessage.Data[5] = mt3;
    TxMessage.Data[6] = mt4 >> 8;
    TxMessage.Data[7] = mt4;
    CAN_Transmit(CAN1,&TxMessage);
}
/*设定GM6020电机电压 :-30000~0~30000*/
void set_gm6020_current(s16 mt1,s16 mt2,s16 mt3,s16 mt4)
{
    CanTxMsg TxMessage;
    TxMessage.StdId= CAN_Tx_6020Moto_5_8;//0X2FF
    TxMessage.IDE = 0;
    TxMessage.RTR = 0;
    TxMessage.DLC = 8;
    TxMessage.Data[0] = mt1 >> 8;
    TxMessage.Data[1] = mt1;
    TxMessage.Data[2] = mt2 >> 8;
    TxMessage.Data[3] = mt2;
    TxMessage.Data[4] = mt3 >> 8;
    TxMessage.Data[5] = mt3;
    TxMessage.Data[6] = mt4 >> 8;
    TxMessage.Data[7] = mt4;
    CAN_Transmit(CAN1,&TxMessage);
}

void odrive_text(s16 mt1,s16 mt2,s16 mt3,s16 mt4)
{
    CanTxMsg TxMessage;
    TxMessage.StdId= 0x217;
    TxMessage.IDE = 0;
    TxMessage.RTR = 0;
    TxMessage.DLC = 8;
    TxMessage.Data[0] = 0x10;
    TxMessage.Data[1] = 0;
    TxMessage.Data[2] = 0;
    TxMessage.Data[3] = 0;
    TxMessage.Data[4] = 0;
    TxMessage.Data[5] = 0;
    TxMessage.Data[6] = 0;
    TxMessage.Data[7] = 0;
    CAN_Transmit(CAN1,&TxMessage);
}
/*设定M2006电流*/
void set_m2006_current(s16 mt1,s16 mt2,s16 mt3,s16 mt4)
{
    CanTxMsg TxMessage;
    TxMessage.StdId= CAN_Tx_2006Moto_5_8;
    TxMessage.IDE = 0;
    TxMessage.RTR = 0;
    TxMessage.DLC = 8;
    TxMessage.Data[0] = mt1 >> 8;
    TxMessage.Data[1] = mt1;
    TxMessage.Data[2] = mt2 >> 8;
    TxMessage.Data[3] = mt2;
    TxMessage.Data[4] = mt3 >> 8;
    TxMessage.Data[5] = mt3;
    TxMessage.Data[6] = mt4 >> 8;
    TxMessage.Data[7] = mt4;
    CAN_Transmit(CAN1,&TxMessage);
}
/*设定超级电容功率*/
void set_can_tx_super_cap(s16 mt1)
{
    CanTxMsg TxMessage;
    TxMessage.StdId= CAN_TX_SUPER_CAP;
    TxMessage.IDE = 0;
    TxMessage.RTR = 0;
    TxMessage.DLC = 8;
    TxMessage.Data[0] = mt1 >> 8;
    TxMessage.Data[1] = mt1;
    TxMessage.Data[2] = 0 >> 8;
    TxMessage.Data[3] = 0;
    TxMessage.Data[4] = 0 >> 8;
    TxMessage.Data[5] = 0;
    TxMessage.Data[6] = 0 >> 8;
    TxMessage.Data[7] = 0;
    CAN_Transmit(CAN1,&TxMessage);
}
/*设定BMI088*/
void set_can_tx_bmi088(uint16_t flag)
{
    CanTxMsg TxMessage;
    TxMessage.StdId= CAN_TX_BMI088_CMD;
    TxMessage.IDE = 0;
    TxMessage.RTR = CAN_RTR_Remote;
    TxMessage.DLC = 8;
    TxMessage.Data[0] = flag >> 8;
    TxMessage.Data[1] = flag;
    TxMessage.Data[2] = 0 >> 8;
    TxMessage.Data[3] = 0;
    TxMessage.Data[4] = 0 >> 8;
    TxMessage.Data[5] = 0;
    TxMessage.Data[6] = 0 >> 8;
    TxMessage.Data[7] = 0;
    CAN_Transmit(CAN2,&TxMessage);
}
//void set_moto6623_current(s16 yaw, s16 pitch)
//{
//	CanTxMsg TxMessage;
//	TxMessage.StdId = CAN_Tx_6623Moto;
//	TxMessage.IDE = 0;
//	TxMessage.RTR = 0;
//	TxMessage.DLC = 8;
//	TxMessage.Data[0] = yaw >> 8;
//	TxMessage.Data[1] = yaw;
//	TxMessage.Data[2] = pitch >> 8;
//	TxMessage.Data[3] = pitch;
////	TxMessage.Data[4] = roll >> 8;
////	TxMessage.Data[5] = roll;
////	TxMessage.Data[6] = resv >> 8;
////	TxMessage.Data[7] = resv;
//	CAN_Transmit(CAN1,&TxMessage);
//}

void Moto6623_Adjust(void)
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x3F0;
    TxMessage.IDE = 0;
    TxMessage.RTR = 0;
    TxMessage.DLC = 8;
    TxMessage.Data[0] = 'c';
    CAN_Transmit(CAN1,&TxMessage);
}


void get_moto_info1(void)
{
    CanRxMsg RxMessage;
    int i;
    CAN_Receive(CAN1,CAN_FIFO0,&RxMessage);
    switch(RxMessage.StdId)
        {
        case CAN_Rx_3508Moto1:
        case CAN_Rx_3508Moto2:
        case CAN_Rx_3508Moto3:
        case CAN_Rx_3508Moto4:
        {
            i=RxMessage.StdId-CAN_Rx_3508Moto1;
            get_moto_measure(&motor_feedback.moto_info_chassis[i], &RxMessage);
            if(motor_feedback.moto_info_chassis[i].speed_rpm > 50000)
                {
                    motor_feedback.moto_info_chassis[i].speed_rpm += -65535;
                }
        }
        break;
        case CAN_Rx_3510Moto1:
        {
            get_moto_measure(&motor_feedback.moto_info_gm3510[0], &RxMessage);
            if(motor_feedback.moto_info_gm3510[0].speed_rpm>50000)
                motor_feedback.moto_info_gm3510[0].speed_rpm += -65535;
        };
        break;
        case CAN_Rx_3510Moto2:
        {
            get_moto_measure(&motor_feedback.moto_info_gm3510[1], &RxMessage);
            if(motor_feedback.moto_info_gm3510[1].speed_rpm>50000)
                motor_feedback.moto_info_gm3510[1].speed_rpm += -65535;
        };
        break;
        case CAN_Rx_2006Moto7:
        {
            get_moto_measure(&motor_feedback.moto_info_m2006[0], &RxMessage);
            if(motor_feedback.moto_info_m2006[0].speed_rpm>50000)
                motor_feedback.moto_info_m2006[0].speed_rpm += -65535;
        }
        break;
        case CAN_Rx_2006Moto8:
        {
            get_moto_measure(&motor_feedback.moto_info_m2006[1], &RxMessage);
            if(motor_feedback.moto_info_m2006[1].speed_rpm>50000)
                motor_feedback.moto_info_m2006[1].speed_rpm += -65535;
        }
        break;
        case CAN_Rx_6020Moto5:
        {
            get_moto_measure(&motor_feedback.moto_info_gm6020[0], &RxMessage);
            if(motor_feedback.moto_info_gm6020[0].speed_rpm>50000)
                motor_feedback.moto_info_gm6020[0].speed_rpm += -65535;
        }
        break;
        case CAN_Rx_6020Moto6:
        {
            get_moto_measure(&motor_feedback.moto_info_gm6020[1], &RxMessage);
            if(motor_feedback.moto_info_gm6020[1].speed_rpm>50000)
                motor_feedback.moto_info_gm6020[1].speed_rpm += -65535;
        }
        break;
        case CAN_RX_SUPER_CAP:
        {

            get_super_capacitor(&motor_feedback.super_cap_info,&RxMessage);
        }
		case 0X0301:
		{
			get_ina226_info_v1(&RxMessage);
		}break;
            /*case CAN_Rx_6623Moto_Yaw:
            {
            	(can_count<=50) ? get_moto_offset_angle(&moto_info_yaw,&RxMessage) : get_moto_measure(&moto_info_yaw,&RxMessage);
            }
            break;
            case CAN_Rx_6623Moto_Pitch:
            {
            	(can_count<=50) ? get_moto_offset_angle(&moto_info_pitch,&RxMessage) : get_moto_measure(&moto_info_pitch,&RxMessage);
            }
            break;*/
        }
}
void get_moto_info2(void)
{
    CanRxMsg RxMessage;
    int i;
    CAN_Receive(CAN2,CAN_FIFO0,&RxMessage);
    switch(RxMessage.StdId)
        {
        case CAN_RX_BMI088_X :
//            get_bmi088x(RxMessage.Data);
            break;
        case CAN_RX_BMI088_Y :
//            get_bmi088y(RxMessage.Data);
            break;
        case CAN_RX_BMI088_Z :
//            get_bmi088z(RxMessage.Data);
            break;
        case CAN_RX_BMI088_YAW :
//            get_bmi088_yaw(RxMessage.Data);
            break;
        case CAN_RX_BMI088_GYRO:
//            get_bmi088_angle(RxMessage.Data);
            break;
        default:
            ;
            break;
        }
}
#define ABS(x)	((x>0) ? (x) : (-x))
/*获取电机信息： 适用于 3508 GM6020 M2006系列*/
void get_moto_measure(mx_moto_info *moto_info,CanRxMsg *RxMessage)
{
    moto_info->last_raw_angle = moto_info->raw_angle;
    /*转子机械角度*/
    moto_info->raw_angle = RxMessage->Data[0]<<8 | RxMessage->Data[1];
    /*转子速度*/
    moto_info->speed_rpm = RxMessage->Data[2]<<8 | RxMessage->Data[3];			//底盘电机3508电调数据帧的2、3位为电机转速
    moto_info->real_current = moto_info->speed_rpm;								//云台电机6623电调数据帧的2、3位为实转矩电流
    /*实际转矩电流*/
    moto_info->give_current = RxMessage->Data[4]<<8 | RxMessage->Data[5];
    moto_info->temperture = RxMessage->Data[6]<<8;
    if(moto_info->raw_angle - moto_info->last_raw_angle > 4096)
        {
            moto_info->round_cnt --;
        }
    else if (moto_info->raw_angle - moto_info->last_raw_angle < -4096)
        {
            moto_info->round_cnt ++;
        }

    if(moto_info->offset_angle_get==0)
        {
            moto_info->offset_angle = moto_info->raw_angle;
            moto_info->round_cnt = 0;
            moto_info->offset_angle_get = 1;
        }
    moto_info->angle = (float)(moto_info->raw_angle*360.0f/8192);
    moto_info->total_angle = (float)(moto_info->round_cnt * 360.0f)
                             + (float)((moto_info->raw_angle - moto_info->offset_angle)*360.0f/8192.0f);
    moto_info->zero_total_angle  = (float)(moto_info->round_cnt * 360.0f)
                                   + (float)((moto_info->raw_angle - moto_info->default_zero_angle)*360.0f/8192.0f);
}

void get_moto_offset_angle(mx_moto_info *p,CanRxMsg *RxMessage)
{
    p->offset_angle = RxMessage->Data[0]<<8 | RxMessage->Data[1];
}
/*获取超级电容信息*/
void get_super_capacitor(mx_super_cap *moto_info_cap,CanRxMsg *RxMessage)
{
    moto_info_cap->input_v=((float)(RxMessage->Data[1]<<8 | RxMessage->Data[0]))/100.f;
    moto_info_cap->cap_v=((float)(RxMessage->Data[3]<<8 | RxMessage->Data[2]))/100.f;
    moto_info_cap->input_current=((float)(RxMessage->Data[5]<<8 | RxMessage->Data[4]))/100.f;
    moto_info_cap->target_power=((float)(RxMessage->Data[7]<<8 | RxMessage->Data[6]))/100.f;
}

float ina226_data_v1[4];

/*获取INA226模块信息*/
void get_ina226_info_v1(CanRxMsg *RxMessage)
{
	
    ina226_data_v1[0]=((float)(RxMessage->Data[0]<<8 | RxMessage->Data[1]))/100.f;
    ina226_data_v1[1]=((float)(RxMessage->Data[2]<<8 | RxMessage->Data[3]))/100.f;
    ina226_data_v1[2]=((float)(RxMessage->Data[4]<<8 | RxMessage->Data[5]))/100.f;
    ina226_data_v1[3]=((float)(RxMessage->Data[6]<<8 | RxMessage->Data[7]))/100.f;
}
void CAN1_RX0_IRQHandler(void)
{
    if(CAN_GetITStatus(CAN1,CAN_IT_FMP0) != RESET)
        {
            CAN_ClearITPendingBit(CAN1, CAN_IT_FF0);
            CAN_ClearFlag(CAN1, CAN_FLAG_FF0);
            get_moto_info1();
        }
}
void CAN2_RX0_IRQHandler(void)
{
    if(CAN_GetITStatus(CAN2,CAN_IT_FMP0) != RESET)
        {
            CAN_ClearITPendingBit(CAN2, CAN_IT_FF0);
            CAN_ClearFlag(CAN2, CAN_FLAG_FF0);
            get_moto_info2();
        }
}

