#ifndef __BSP_CAN_H
#define __BSP_CAN_H

/*
--------函数功能--------
1、CAN1初始化
2、云台电机6623电调自校准
3、底盘电机3508电流设置
4、云台电机6623电流设置
5、CAN接受电机返回信息
*/

#include "stdio.h"
#include "stm32f4xx_conf.h"

#define DEFAULT_ANGLE_YAW  3790
#define DEFAULT_ANGLE_PITCH 4200

typedef struct
{
    uint8_t offset_angle_get;
    //未经处理的电调返回值
    uint16_t raw_angle;			//机械角度
    uint8_t  temperture;		//电机温度
    int16_t  speed_rpm;		  	//电机转速
    int16_t  real_current;		//实际转矩电流
    int16_t  give_current;		//给定转矩电流
    //通过处理后的电机信息

    int32_t  round_cnt;			//转过的圈数
    uint16_t offset_angle;		//开机角度
    uint16_t last_raw_angle;	//上一次电调返回未处理的机械角度
    uint16_t default_zero_angle;//默认零点

    float  angle;			 //通过raw_angle转换 取值范围(0-360)
    float  total_angle;		 //电机转过的角度和
    float  zero_total_angle; //相对于默认零点角度
} mx_moto_info;
typedef struct
{
    float input_v;
    float cap_v;
    float input_current;
    float target_power;
    float Power_send;
} mx_super_cap;
typedef struct
{
    mx_super_cap    super_cap_info;
    mx_moto_info moto_info_chassis[4];
    mx_moto_info moto_info_m2006[2];
    mx_moto_info moto_info_gm6020[2];
    mx_moto_info moto_info_gm3510[2];
} total_info;

typedef enum
{
    /*3008*系列*/
    CAN_Tx_3508Moto_1_4 = 0x200,
    CAN_Rx_3508Moto1 = 0x201,
    CAN_Rx_3508Moto2 = 0x202,
    CAN_Rx_3508Moto3 = 0x203,
    CAN_Rx_3508Moto4 = 0x204,
//	CAN_Tx_3508Moto_5_8 = 0x1FF,
//	CAN_Rx_3508Moto5 = 0x205,
//	CAN_Rx_3508Moto6 = 0x206,
//	CAN_Rx_3508Moto7 = 0x207,
//	CAN_Rx_3508Moto8 = 0x208,

    /*M2006系列*/
//	CAN_Tx_2006Moto_1_4 = 0x200,
//	CAN_Rx_2006Moto1 =0x201,
//	CAN_Rx_2006Moto2 =0x202,
//	CAN_Rx_2006Moto3 = 0x203,
//	CAN_Rx_2006Moto4 = 0x204,
    CAN_Tx_2006Moto_5_8 = 0X1FF,
//	CAN_Rx_2006Moto5 =0x205,
//	CAN_Rx_2006Moto6 =0x206,
    CAN_Rx_2006Moto7 = 0x207,
    CAN_Rx_2006Moto8 = 0x208,

    /*GM6020系列*/
//	CAN_Tx_6020Moto_1_4 = 0X1FF,
//	CAN_Rx_6020Moto1 = 0X205,
//	CAN_Rx_6020Moto2 = 0X206,
//	CAN_Rx_6020Moto3 = 0X207,
//	CAN_Rx_6020Moto4 = 0X208,
    CAN_Tx_6020Moto_5_8 = 0X2FF,
    CAN_Rx_6020Moto5 = 0X209,
    CAN_Rx_6020Moto6 = 0X20A,
    CAN_Rx_6020Moto7 = 0X20B,

    /*GM3510系列*/
//	CAN_Tx_3510Moto = 0X1FF,
    CAN_Rx_3510Moto1 = 0X205,
    CAN_Rx_3510Moto2 = 0X206,
//	CAN_Rx_3510Moto3 = 0X207,

    /*超级电容*/
    CAN_RX_SUPER_CAP = 0X211,
    CAN_TX_SUPER_CAP = 0X210,
    /*6623系列*/
//	CAN_Tx_6623Moto = 0X1F0,
//	CAN_Rx_6623Moto_Yaw = 0x205,
//	CAN_Rx_6623Moto_Pitch = 0x206,
//	CAN_Rx_6623Moto_Roll = 0x207,
//	CAN_Rx_6623Moto_Resv = 0x208,
//	CAN_Rx_6623Moto_Ex1 = 0x209,
//	CAN_Rx_6623Moto_Ex2 = 0x20A,
//	CAN_Rx_6623Moto_Ex3 = 0x20B,
//	CAN_Rx_6623Moto_Ex4 = 0x20C,

    CAN_RX_BMI088_X = 0X301,
    CAN_RX_BMI088_Y = 0X302,
    CAN_RX_BMI088_Z = 0X303,
    CAN_RX_BMI088_YAW = 0X304,
    CAN_RX_BMI088_GYRO = 0X305,
    CAN_TX_BMI088_CMD = 0X306,
} CAN_Message_ID;


const total_info* get_motor_info_data(void);
void mx_can1_init(void);
void mx_can2_init(void);
void Moto6623_Adjust(void);

void set_moto6623_current(s16 yaw, s16 pitch);
void odrive_text(s16 mt1,s16 mt2,s16 mt3,s16 mt4);
void get_super_capacitor(mx_super_cap *moto_info_cap,CanRxMsg *RxMessage);
void get_ina226_info_v1(CanRxMsg *RxMessage);
void get_moto_info1(void);
void get_moto_info2(void);
void get_moto_measure(mx_moto_info *moto_info,CanRxMsg *RxMessage);
void get_moto_offset_angle(mx_moto_info *p,CanRxMsg *RxMessage);
void Get_Total_Angle(mx_moto_info *p);

void set_m3508_current(s16 mt1,s16 mt2,s16 mt3,s16 mt4);
void set_gm6020_current(s16 mt1,s16 mt2,s16 mt3,s16 mt4);
void set_m2006_current(s16 mt1,s16 mt2,s16 mt3,s16 mt4);
void set_can_tx_super_cap(s16 mt1);
void set_can_tx_bmi088(uint16_t flag);
#endif
