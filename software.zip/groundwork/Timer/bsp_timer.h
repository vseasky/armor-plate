#ifndef _BSP_TIMER_H
#define _BSP_TIMER_H
#include "sys.h"
void mx_tim3_init(void);

extern volatile unsigned long long FreeRTOSRunTimeTicks;
void ConfigureTimeForRunTimeStats(void);
#endif
