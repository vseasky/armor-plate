#ifndef __BSP_GPIO_H
#define __BSP_GPIO_H

/*
--------函数功能--------
1、LED初始化
2、按键初始化
3、24V电源口初始化
4、按键扫描消抖函数
5、蜂鸣器初始化
6、RTC实时时钟（由于LSE的问题，rb开发板不能使用）
*/

#include "stdio.h"	
#include "delay.h"

#define LED1 PDout(11)
#define LED2 PDout(10)
#define LED3 PGout(2)
#define LED4 PGout(3)
#define LED5 PGout(4)
#define LED6 PGout(5)
#define LED7 PGout(6)
#define LED8 PGout(7)

#define LED_R1 PGout(9)
#define LED_R2 PGout(10)



void mx_led_init(void);
void succeeded_led(void);


#endif
