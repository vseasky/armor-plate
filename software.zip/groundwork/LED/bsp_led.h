#ifndef __LED_H
#define __LED_H
#include "stm32f10x.h"
#include "sys.h"

#define LED0 PBout(14)
void mx_led_init(void);//��ʼ��		 				    
#endif
