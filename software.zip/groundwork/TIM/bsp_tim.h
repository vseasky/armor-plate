#ifndef _BSP_TIM_H
#define _BSP_TIM_H
#include "stm32f4xx.h"

void mx_tim12_init(void);

void mx_tim1_init(void);
void mx_tim2_init(void);
void mx_tim4_init(void);
void mx_tim5_init(void);
void mx_tim8_init(void);
#endif

