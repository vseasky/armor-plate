Seasky STM32F427IIH6学习板资源

过压保护、防反接、输入缓启动

电源：
	24V---->5V4A>>>>>>PWMx20
		       >>>>>>GPIOx2
		       >>>>>>ADCx1

	24V---->5V1A>>>>>>3V3------>STM32 CORE
		       >>>>>>....
		       >>>>>>3V3------>OLED

	

PWM通道		-> 4x5
USART 		-> x6
CAN		-> x2
IIC		-> x3
SPI		-> x3
GPIO		-> x2
GPIO转5V	-> x4
OLED(SPI,ADC)	-> x1
ADC		-> 1+8
DBUS-UART	-> x1
激光		-> x1
LED		-> 8+2
USB		-> x1
SD卡		-> x1
蜂鸣器		-> x1
WS2812		-> x1
WAKE_UP(按键）	-> x1
