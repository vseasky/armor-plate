#include "FreeRTOS.h"
#include "task.h"

#include "start_task.h"

#include "sys.h"
#include "delay.h"
#include "bsp_led.h"
#include "bsp_dbus.h"
#include "usbd_cdc_vcp.h"
#include "usbd_usr.h"
#include "bsp_oled.h"
#include "bsp_spi.h"
#include "bsp_adc.h"
#include "bsp_key.h"
#include "bsp_tim.h"
#include "bsp_ws2812.h"
#include "bsp_can.h"
#include "bsp_sdcard.h"
#include "bsp_usart.h"
/*
	ϵͳʱ�� = HSE(12MHz)*N(180)/(M(6)*P(4)) = 180MHz
	ClocksTypeDef.SYSCLK_Frequency = 180000000
	ClocksTypeDef.HCLK_Frequency = 180000000
	ClocksTypeDef.PCLK1_Frequency = 45000000
	ClocksTypeDef.PCLK2_Frequency = 90000000
	�˴���ʹ�õ�180M
*/

/*******************************
	ϵͳʱ�� = HSE(12MHz)*N(168)/(M(6)*P(2)) = 168MHz
	ClocksTypeDef.SYSCLK_Frequency = 168000000
	ClocksTypeDef.HCLK_Frequency = 168000000
	ClocksTypeDef.PCLK1_Frequency = 42000000
	ClocksTypeDef.PCLK2_Frequency = 84000000
	APB1 42M
	APB1_TIMER_CLK 84M
	APB2 84M
	APB2_TIMER_CLK 168M
	PLL_Q = 7 USB_PCLK 48M
	����USB_PCLK����Ϊ48M������Ƶֻʹ�õ�168M
*******************************/
RCC_ClocksTypeDef ClocksTypeDef;
int main(void)
{
    int i = 0;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);//����ϵͳ�ж����ȼ�����4
    delay_init(168);//��ʼ����ʱ����
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    GPIO_PinAFConfig(GPIOA,GPIO_Pin_14,GPIO_AF_SWJ);
    GPIO_PinAFConfig(GPIOA,GPIO_Pin_13,GPIO_AF_SWJ);
    RCC_GetClocksFreq(&ClocksTypeDef);
    mx_led_init();
    mx_key_init();
    mx_dbus_init();
//    while(mx_sd_init())
//        {
//            i++;
//            if(i>2000)break;
//        }
    mx_adc_init();
    mx_spi1_init();
    mx_oled_init();
    mx_tim12_init();
    mx_ws2812_gpio_init();
    mx_tim1_init();
    mx_tim2_init();
    mx_tim4_init();
    mx_tim5_init();
    mx_tim8_init();
    mx_usart1_init();
    mx_usart2_init();
    mx_usart3_init();
    mx_usart6_init();
    mx_uart7_init();
    mx_uart8_init();
    mx_can1_init();
    mx_can2_init();
	usbd_cdc_vcp_Init();

//    if(i>=2000)
//        {
//            usb_printf("SD_CARD ERROR");
//        }
//    else if(i<2000)
//        {
//            usb_printf("SD_CARD OK\r\n");
//        }
	delay_ms(3000);
    succeeded_led();
    create_start_task();	//������ʼ����
    vTaskStartScheduler();  //�����������
    while(1) {}
}





