#include "start_task.h"

#include "FreeRTOS.h"
#include "task.h"
#include "bsp_led.h"
#include "delay.h"

#include "bsp_gui.h"
#include "bsp_oled.h"
#include "bsp_key.h"
#include "music_task.h"
#include "bsp_ws2812.h"

#include "bsp_can.h"
#include "usbd_cdc_vcp.h"
#include "usbd_usr.h"
#define START_TASK_PRIO 1
#define START_TASK_STK_SIZE 128
TaskHandle_t Start_Task_Handler;

#define LED0_TASK_PRIO 2
#define LED0_TASK_STK_SIZE 256
TaskHandle_t Led0_Task_Handler;

#define LED1_TASK_PRIO 3
#define LED1_TASK_STK_SIZE 256
TaskHandle_t Led1_Task_Handler;

#define KEY_TASK_PRIO 4
#define KEY_TASK_STK_SIZE 128
TaskHandle_t Key_Task_Handler;

#define OLED_TASK_PRIO 5
#define OLED_TASK_STK_SIZE 128
TaskHandle_t Oled_Task_Handler;


#define MUSIC_TASK_PRIO 6
#define MUSIC_TASK_STK_SIZE 128
TaskHandle_t Music_Task_Handler;


#define RGB_TASK_PRIO 6
#define RGB_TASK_STK_SIZE 128
TaskHandle_t Rgb_Task_Handler;

void create_start_task(void)
{
    xTaskCreate((TaskFunction_t)start_task,
                (char*         )"start_task",
                (uint16_t      )START_TASK_STK_SIZE,
                (void *        )NULL,
                (UBaseType_t   )START_TASK_PRIO,
                (TaskHandle_t*)&Start_Task_Handler);
}
void led0_task(void *pvParameters)
{
    while(1)
        {
            LED2=!LED2;
            LED4=!LED4;
            LED6=!LED6;
            LED8=!LED8;
            LED_R1=!LED_R1;
            LED_R2=!LED_R2;
            vTaskDelay(500);
        }
}
void led1_task(void *pvParameters)
{
    while(1)
        {
            LED1=!LED1;
            LED3=!LED3;
            LED5=!LED5;
            LED7=!LED7;
//          set_m3508_current(700,700,700,700);
            vTaskDelay(1000);
        }
}
void oled_task(void *pvParameters)
{
    OLED_Clear();
    while(1)
        {
			//ws2812show(0x00000ff0);
            interface_main();//����oled
            vTaskDelay(50);
        }
}

#define RGB_FLOW_COLOR_CHANGE_TIME  200
#define RGB_FLOW_COLOR_LENGHT   6
//blue-> green(dark)-> red -> blue(dark) -> green(dark) -> red(dark) -> blue
//�� -> ��(��) -> �� -> ��(��) -> �� -> ��(��) -> �� 
uint32_t RGB_flow_color[RGB_FLOW_COLOR_LENGHT + 1] = {0xFF0000FF, 0x0000FF00, 0xFFFF0000, 0x000000FF, 0xFF00FF00, 0x00FF0000, 0xFF0000FF};
float delta_alpha, delta_red, delta_green, delta_blue;
float alpha,red,green,blue;
void rgb_task(void *pvParameters)
{
    uint8_t k;	
	uint16_t i, j;
    uint32_t aRGB;
	while(1)
	{
			for(i = 0; i < RGB_FLOW_COLOR_LENGHT; i++)
        {

            red = ((RGB_flow_color[i] & 0x00FF0000) >> 16);
            green = ((RGB_flow_color[i] & 0x0000FF00) >> 8);
            blue = ((RGB_flow_color[i] & 0x000000FF) >> 0);

            delta_red = (float)((RGB_flow_color[i + 1] & 0x00FF0000) >> 16) - (float)((RGB_flow_color[i] & 0x00FF0000) >> 16);
            delta_green = (float)((RGB_flow_color[i + 1] & 0x0000FF00) >> 8) - (float)((RGB_flow_color[i] & 0x0000FF00) >> 8);
            delta_blue = (float)((RGB_flow_color[i + 1] & 0x000000FF) >> 0) - (float)((RGB_flow_color[i] & 0x000000FF) >> 0);

            delta_red /= RGB_FLOW_COLOR_CHANGE_TIME;
            delta_green /= RGB_FLOW_COLOR_CHANGE_TIME;
            delta_blue /= RGB_FLOW_COLOR_CHANGE_TIME;
            for(j = 0; j < RGB_FLOW_COLOR_CHANGE_TIME; j++)
            {
                red += delta_red;
                green += delta_green;
                blue += delta_blue;
                aRGB =  ((uint32_t)(red/5)) << 16 | ((uint32_t)(green/5)) << 8 | ((uint32_t)(blue/5)) << 0;
				/*ʵ��Ч�����Ծ�ȷ����ָ��LED*/
				ws2812show(aRGB);
				odrive_text(0,0,0,0);
                vTaskDelay(500);
            }
        }
	}
}
void start_task(void *pvParameters)
{
    taskENTER_CRITICAL();
    xTaskCreate((TaskFunction_t)led0_task,
                (char*         )"led0_task",
                (uint16_t      )LED0_TASK_STK_SIZE,
                (void *        )NULL,
                (UBaseType_t   )LED0_TASK_PRIO,
                (TaskHandle_t*)&Led0_Task_Handler);
    xTaskCreate((TaskFunction_t)led1_task,
                (char*         )"led1_task",
                (uint16_t      )LED1_TASK_STK_SIZE,
                (void *        )NULL,
                (UBaseType_t   )LED1_TASK_PRIO,
                (TaskHandle_t*)&Led1_Task_Handler);
    xTaskCreate((TaskFunction_t)key_scan_task,
                (char*         )"key_scan_task",
                (uint16_t      )KEY_TASK_STK_SIZE,
                (void *        )NULL,
                (UBaseType_t   )KEY_TASK_PRIO,
                (TaskHandle_t*)&Key_Task_Handler);
    xTaskCreate((TaskFunction_t)oled_task,
                (char*         )"oled_task",
                (uint16_t      )OLED_TASK_STK_SIZE,
                (void *        )NULL,
                (UBaseType_t   )OLED_TASK_PRIO,
                (TaskHandle_t*)&Oled_Task_Handler);
//    xTaskCreate((TaskFunction_t)musicPlay_task,
//                (char*         )"musicPlay_task",
//                (uint16_t      )MUSIC_TASK_STK_SIZE,
//                (void *        )NULL,
//                (UBaseType_t   )MUSIC_TASK_PRIO,
//                (TaskHandle_t*)&Music_Task_Handler);
	xTaskCreate((TaskFunction_t)rgb_task,
                (char*         )"rgb_task",
                (uint16_t      )RGB_TASK_STK_SIZE,
                (void *        )NULL,
                (UBaseType_t   )RGB_TASK_PRIO,
                (TaskHandle_t*)&Rgb_Task_Handler);
    vTaskDelete(Start_Task_Handler);
    taskEXIT_CRITICAL();
}

