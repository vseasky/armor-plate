#ifndef _BSP_WS2812_H
#define _BSP_WS2812_H
#include "stm32f4xx.h"
#include "sys.h"

#define WS2812 PHout(9)

void mx_ws2812_gpio_init(void);
void ws2812show(uint32_t RGB_SET);
#endif
