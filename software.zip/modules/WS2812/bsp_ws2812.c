#include "bsp_ws2812.h"
#include "delay.h"
/*

	24bit 0-7->B;8-15->R;16->23->G
*/
void mx_ws2812_gpio_init(void)
{
    //TIM12_CH2/PH9

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOH,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOH, &GPIO_InitStructure);
    WS2812 = 0;
}
uint16_t delay_count[4]={10,35,35,15};
void WS2812_Write0(void)
{
	
	WS2812 = 1;
	for(int i=0;i<5;i++)//0.2-0.4us
	{	
		__nop();
	}
	WS2812 = 0;
	for(int i=0;i<95;i++)//
	{	
		__nop();
	}
}
void WS2812_Write1(void)
{
	
	WS2812 = 1;
	for(int i=0;i<24;i++)//0.58-1.0us
	{	
		__nop();//0.04us
	}
	WS2812 = 0;
	for(int i=0;i<76;i++)
	{	
		__nop();
	}
}
void WS2812_Reset(void)
{
//	WS2812 = 1;
//	for(int i=0;i<35;i++)//0.58-1.0us
//	{	
//		__nop();//0.04us
//	}
	WS2812 = 0;
	//����Ǵ���80us���ڵ��ô˴���ʱ����ʡ��
//	delay_us(80);
}
void ws2812show(uint32_t RGB_SET)
{
	WS2812 = 0;
	int i=0;
	i=0;
	for(i=0;i<24;i++)
	{
		if(((RGB_SET<<i)&0X00800000))
		{
			WS2812_Write1();
		}
		else
		{
			WS2812_Write0();
		}
	}
	WS2812_Reset();
}