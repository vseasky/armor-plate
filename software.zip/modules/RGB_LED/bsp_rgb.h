#ifndef _BSP_RGB_H
#define _BSP_RGB_H

#include "sys.h"


void mx_tim3_init(void);
void mx_tim4_init(void);
#endif
