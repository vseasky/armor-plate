#ifndef _MX_MUSIC_CONFIG_H
#define _MX_MUSIC_CONFIG_H

//���������ˣ���ʵ�ѳ�
//����ʱֵ��λ,����������ٶ� msΪ��λ 2000Ϊ��
//#define TT 2697
#define TT 2697

////�����������C
//#define L1 262
//#define L2 294
//#define L3 330
//#define L4 349
//#define L5 392
//#define L6 440
//#define L7 494

////������������C
//#define M1 523
//#define M2 587
//#define M3 659
//#define M4 698
//#define M5 784
//#define M6 880
//#define M7 988

////�����������C
//#define H1 1047
//#define H2 1175
//#define H3 1319
//#define H4 1397
//#define H5 1568
//#define H6 1760
//#define H7 1976

////�����������D
//#define L1 294
//#define L2 330
//#define L3 370
//#define L4 392
//#define L5 440
//#define L6 494
//#define L7 554

////������������D
//#define M1 587
//#define M2 659
//#define M3 740
//#define M4 784
//#define M5 880
//#define M6 988
//#define M7 1109

////�����������D
//#define H1 1175
//#define H2 1319
//#define H3 1480
//#define H4 1568
#define H5 1760
#define H6 1976
#define H7 2217

////�����������E
//#define L1 330
//#define L2 370
//#define L3 415
//#define L4 440
//#define L5 494
//#define L6 554
//#define L65 587
//#define L7 622

////������������E
//#define M1 659
//#define M2 740
//#define M3 831
//#define M4 880
//#define M5 988
//#define M6 1109
//#define M7 1245

////�����������E
//#define H1 1319
//#define H2 1480
//#define H3 1661
//#define H4 1760
//#define H5 1976

//�����������F (��λ��Hz)
#define L1 349
#define L2 392
#define L3 440
#define L4 466
#define L5 523
#define L6 587
#define L7 659

//������������F
#define M1 698
#define M2 784
#define M3 880
#define M4 932
#define M5 1047
#define M6 1175
#define M7 1319

//�����������F
#define H1 1397
#define H2 1568
#define H3 1760
#define H4 1865

typedef struct
{
    short mName; //����
    short mTime; //ʱֵ,ȫ����,��������,�ķ�����
} tNote;
//Always with me  (һ��674.15)*4=2697 F��
#define Always_with_me_length 256
const tNote Always_with_me[Always_with_me_length]=
{
    {0,TT/2},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M1,TT/8},{M5,TT/4+TT/8},{M3,TT/8},
    {M2,TT/4},{M5,TT/4},{M2,TT/4},{M1,TT/8},{L6,TT/8},{M3,TT/4+TT/8},{M1,TT/8},
    {L7,TT/2},{M1,TT/8},{L7,TT/8},{L6,TT/4},{L7,TT/4},{M1,TT/8},{M2,TT/8},
    {L5,TT/4},{M1,TT/4},{M2,TT/8},{M3,TT/8},{M4,TT/4},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
    {M2,TT/2},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M1,TT/8},{M5,TT/4+TT/8},{M3,TT/8},
    {M2,TT/4},{M5,TT/4},{M2,TT/4},{M1,TT/8},{L6,TT/8},{L6,TT/4},{L7,TT/8},{M1,TT/8},
    {L5,TT/2},{0,TT/8},{L5,TT/8},{L6,TT/4},{L7,TT/4},{M1,TT/8},{M2,TT/8},//question
    {L5,TT/4},{M1,TT/4},{M2,TT/8},{M3,TT/8},{M4,TT/4},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/2+TT/4},

    {0,TT/2},{M3,TT/8},{M4,TT/8},{M5,TT/4},{M5,TT/4},{M5,TT/4},{M5,TT/4},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},
    {M3,TT/4},{M3,TT/4},{M3,TT/4},{M3,TT/4},{M3,TT/8},{M4,TT/8},{M3,TT/8},{M2,TT/8},
    {M1,TT/4},{M1,TT/4},{M1,TT/8},{L7,TT/8},{L6,TT/4},{L7,TT/4},{L7,TT/8},{M1,TT/8},
    {M2,TT/4},{M2,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M2,TT/2},{M3,TT/8},{M4,TT/8},
    {M5,TT/4},{M5,TT/4},{M5,TT/4},{M5,TT/4},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},
    {M3,TT/4},{M3,TT/4},{M3,TT/4},{M3,TT/8},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{L7,TT/8},
    {L6,TT/4},{L6,TT/8},{L7,TT/8},{M1,TT/8},{M2,TT/8},{L5,TT/4},{M1,TT/4},{M2,TT/8},{M3,TT/8},
    {M2,TT/4+TT/8},{M2,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/2+TT/4},

    {0,TT/2},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M1,TT/8},{M5,TT/4+TT/8},{M3,TT/8},
    {M2,TT/4},{M5,TT/4},{M2,TT/4},{M1,TT/8},{L6,TT/8},{M3,TT/4+TT/8},{M1,TT/8},
    {L7,TT/2},{M1,TT/8},{L7,TT/8},{L6,TT/4},{L7,TT/4},{M1,TT/8},{M2,TT/8},
    {L5,TT/4},{M1,TT/4},{M2,TT/8},{M3,TT/8},{M4,TT/4},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},
    {M2,TT/2},{M1,TT/8},{M2,TT/8},{M3,TT/8},{M1,TT/8},{M5,TT/4+TT/8},{M3,TT/8},
    {M2,TT/4},{M5,TT/4},{M2,TT/4},{M1,TT/8},{L6,TT/8},{L6,TT/4},{L7,TT/8},{M1,TT/8},
    {L5,TT/2},{0,TT/8},{L5,TT/8},{L6,TT/4},{L7,TT/4},{M1,TT/8},{M2,TT/8},//question
    {L5,TT/4},{M1,TT/4},{M2,TT/8},{M3,TT/8},{M4,TT/4},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/2+TT/4},

    {0,TT/2},{M3,TT/8},{M4,TT/8},{M5,TT/4},{M5,TT/4},{M5,TT/4},{M5,TT/4},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},
    {M3,TT/4},{M3,TT/4},{M3,TT/4},{M3,TT/4},{M3,TT/8},{M4,TT/8},{M3,TT/8},{M2,TT/8},
    {M1,TT/4},{M1,TT/4},{M1,TT/8},{L7,TT/8},{L6,TT/4},{L7,TT/4},{L7,TT/8},{M1,TT/8},
    {M2,TT/4},{M2,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M2,TT/2},{M3,TT/8},{M4,TT/8},
    {M5,TT/4},{M5,TT/4},{M5,TT/4},{M5,TT/4},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M4,TT/8},
    {M3,TT/4},{M3,TT/4},{M3,TT/4},{M3,TT/8},{M4,TT/8},{M3,TT/8},{M2,TT/8},{M1,TT/8},{L7,TT/8},
    {L6,TT/4},{L6,TT/8},{L7,TT/8},{M1,TT/8},{M2,TT/8},{L5,TT/4},{M1,TT/4},{M2,TT/8},{M3,TT/8},
    {M2,TT/4+TT/8},{M2,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/2+TT/4},
};

#define HaoYunLai_Length 156
const tNote HaoYunLai[HaoYunLai_Length]=
{
    {M6,TT/4},{H3,TT/8+TT/16},{H2,TT/16},{H2,TT/4},{H1,TT/8},{M6,TT/8},
    {M5,TT/4},{H1,TT/8+TT/16},{H2,TT/16},{M6,TT/4},{0,TT/4},
    {M6,TT/4},{H2,TT/4},{H1,TT/4},{M6,TT/8},{M5,TT/8},
    {M2,TT/4},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/4},{0,TT/8},
    //������ף������������˴�����ϲ�Ͱ�
    {M3,TT/4},{M6,TT/8+TT/16},{M5,TT/16},{M6,TT/4},{M6,TT/8},{M5,TT/8},
    {M6,TT/4},{H2,TT/8+TT/16},{H1,TT/16},{H2,TT/4},{0,TT/4},
    {H1,TT/8+TT/16},{H1,TT/16},{H1,TT/8},{H2,TT/8},{H3,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/8},
    {M5,TT/4},{H1,TT/8+TT/16},{M6,TT/16}, {M6,TT/2+TT/4},{0,TT/4},
    //���������Ǻ�������ӭ�ź�����������ͨ�ĺ�


    {M6,TT/8+TT/16},{M6,TT/16},{H1,TT/8},{H1,TT/8},{M6,TT/4},{0,TT/8},{M6,TT/8},
    {M5,TT/8},{M3,TT/8},{M5,TT/8},{H1,TT/8},{M6,TT/4},{0,TT/4},
    //����ǧֽ�ף���ϵ��������
    {M6,TT/8},{H1,TT/8},{H1,TT/8+TT/16},{H1,TT/16},{H1,TT/8},{M6,TT/8},{M5,TT/4},
    {M6,TT/8},{M5,TT/8},{M2,TT/8},{M5,TT/8},{M3,TT/4},{0,TT/8},{M2,TT/8},
    //Ը�������������������
    {M3,TT/8},{M2,TT/8},{M1,TT/8},{M3,TT/8},{M2,TT/4},{0,TT/8},{M3,TT/8},
    {M6,TT/8},{M5,TT/8},{M3,TT/8},{M6,TT/8},{M6,TT/8},{M5,TT/4},{0,TT/8},
    //���������������㽡��������
    {M6,TT/8},{H1,TT/8},{H1,TT/8+TT/16},{M6,TT/16},{H2,TT/8},{H2,TT/8},{H2,TT/8},{H1,TT/8},
    {M6,TT/4},{M5,TT/8},{H1,TT/8},{M6,TT/2+TT/4},{0,TT/4},
    //��һ����æµΪ��Ц���տ�

    {M6,TT/4},{H3,TT/8+TT/16},{H2,TT/16},{H2,TT/4},{H1,TT/8},{M6,TT/8},
    {M5,TT/4},{H1,TT/8+TT/16},{H2,TT/16},{M6,TT/4},{0,TT/4},
    {M6,TT/4},{H2,TT/4},{H1,TT/4},{M6,TT/8},{M5,TT/8},
    {M2,TT/4},{M5,TT/8},{M6,TT/8},{M5,TT/8},{M3,TT/4},{0,TT/8},
    //������ף������������˴�����ϲ�Ͱ�
    {M3,TT/4},{M6,TT/8+TT/16},{M5,TT/16},{M6,TT/4},{M6,TT/8},{M5,TT/8},
    {M6,TT/4},{H2,TT/8+TT/16},{H1,TT/16},{H2,TT/4},{0,TT/4},
    {H1,TT/8+TT/16},{H1,TT/16},{H1,TT/8},{H2,TT/8},{H3,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/8},
    {M5,TT/4},{H1,TT/8+TT/16},{M6,TT/16}, {M6,TT/2+TT/4},{0,TT/4},
    //���������Ǻ�������ӭ�ź�����������ͨ�ĺ�
    {H2,TT/4+TT/2},{0,TT/4},{H3,TT/4+TT/2},{0,TT/4},{M6,TT/4+TT/2},
    {0,TT/4},{M5,TT/8},{M5,TT/8},{M6,TT/4},{0,TT/4},
    //ͨ�ĺ���������
};
//��ʱ���� ���� �е���ǿ  D��
#define HuaFeng_Length 357
const tNote HuaFeng[HuaFeng_Length]=
{
    {0,TT/8},{H3,TT/8},{H5,TT/8},{H3,TT/16},{H2,TT/16},{H2,TT/4},
    {0,TT/8},{H2,TT/8},{H5,TT/8},{H2,TT/16},{H1,TT/16},{H1,TT/4},
    {0,TT/8},{H3,TT/8},{H5,TT/8},{H3,TT/16},{H2,TT/16},{H2,TT/4},{H1,TT/8},{M6,TT/16},{H1,TT/16},
    {H1,TT/1},
    {0,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},{M3,TT/16},{M2,TT/16},{M2,TT/8},
    {0,TT/8},{M2,TT/8},{M1,TT/8},{M2,TT/8},{M5,TT/8},{M2,TT/16},{M1,TT/16},{0,TT/8},{M5,TT/8},
    {M6,TT/8},{H1,TT/8},{M6,TT/16},{M5,TT/16},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},
    {M5,TT/8},{M3,TT/8},{M3,TT/2},{0,TT/4},
    {0,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},{M3,TT/16},{M2,TT/16},{M2,TT/8},
    {0,TT/8},{M2,TT/8},{M1,TT/8},{M2,TT/8},{M5,TT/8},{M2,TT/16},{M1,TT/16},{0,TT/8},{M5,TT/8},
    {M6,TT/8},{M5,TT/8},{M5,TT/8},{M3,TT/8},{M3,TT/8},{M2,TT/8},{M2,TT/16},{M1,TT/16},{M1,TT/8},
    {M1,TT/2},{0,TT/4},{0,TT/4},
    {0,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},{M3,TT/16},{M2,TT/16},{M2,TT/8},
    {0,TT/8},{M2,TT/8},{M1,TT/8},{M2,TT/8},{M5,TT/8},{M2,TT/8},{M1,TT/8},{0,TT/8},{M5,TT/8},
    {M6,TT/8},{H1,TT/8},{M6,TT/16},{M5,TT/16},{M5,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M6,TT/16},{M5,TT/16},
    {M3,TT/8},{M3,TT/8},{M3,TT/2},{0,TT/4},
    {0,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},{M6,TT/16},{M3,TT/16},{M3,TT/16},{M2,TT/8},{M2,TT/16},
    {0,TT/8},{M2,TT/8},{M1,TT/8},{M2,TT/8},{M5,TT/8},{M2,TT/16},{M1,TT/16},{0,TT/8},{M5,TT/8},
    {M3,TT/4},{M1,TT/4},{L6,TT/8},{M2,TT/8},{M1,TT/8},{M1,TT/8},
    {M1,TT/2},{0,TT/8},{M6,TT/8},{M3,TT/8},{H2,TT/16},{H1,TT/16},
    {H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{0,TT/8},{M5,TT/8},{H2,TT/8},{H1,TT/8},
    {M7,TT/8},{H1,TT/8},{H2,TT/8},{H1,TT/16},{H1,TT/16},{H1,TT/8},{M5,TT/16},{M6,TT/8},{H1,TT/16},
    {H1,TT/4},{0,TT/16},{M5,TT/16},{M6,TT/16},{H1,TT/16},{H3,TT/8},{H2,TT/16},{H1,TT/16},{H1,TT/8},{H3,TT/8},
    {H3,TT/2},{0,TT/8},{M6,TT/8},{H3,TT/8},{H2,TT/16},{H1,TT/16},
    {H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{0,TT/8},{H5,TT/8},{H2,TT/8},{H1,TT/8},
    {H2,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/16},{H1,TT/16},{H1,TT/4},{M5,TT/16},{M6,TT/8},{H1,TT/16},
    {H1,TT/4},{0,TT/16},{M5,TT/16},{M5,TT/16},{H3,TT/16},{H2,TT/16},{H1,TT/16},{H1,TT/8},{M6,TT/8},{H1,TT/8},
    {H1,TT/2},{0,TT/8},{M6,TT/8},{H3,TT/8},{H2,TT/16},{H1,TT/16},
    {H1,TT/8},{H2,TT/8},{H3,TT/8},{H2,TT/8},{0,TT/8},{M5,TT/8},{H2,TT/8},{H1,TT/8},
    {M7,TT/8},{H1,TT/8},{H2,TT/8},{H1,TT/16},{H1,TT/16},{H1,TT/4},{M5,TT/16},{M6,TT/8},{H1,TT/16},
    {H1,TT/4},{0,TT/16},{M5,TT/16},{M6,TT/16},{H1,TT/16},{H3,TT/8},{H2,TT/16},{H1,TT/16},{H1,TT/8},{H3,TT/8},
    {H3,TT/2},{0,TT/8},{M6,TT/8},{H3,TT/8},{H2,TT/16},{H1,TT/16},
    {H1,TT/8},{8,TT/8},{H3,TT/8},{H2,TT/8},{0,TT/8},{H5,TT/8},{H2,TT/16},{H1,TT/16},{H1,TT/8},
    {H2,TT/8},{H3,TT/8},{H2,TT/8},{H1,TT/16},{H1,TT/16},{H1,TT/4},{M5,TT/16},{M6,TT/8},{M1,TT/16},
    {H1,TT/4},{0,TT/16},{M5,TT/16},{M6,TT/16},{H3,TT/16},{H2,TT/16},{H1,TT/16},{H1,TT/8},{M6,TT/8},{H2,TT/8},
    {H1,TT/2},{0,TT/4},{0,TT/4},
    {0,TT/8},{H3,TT/8},{H5,TT/8},{H3,TT/16},{H2,TT/16},{H2,TT/2},
    {0,TT/8},{H2,TT/8},{H5,TT/8},{H2,TT/16},{H1,TT/16},{H1,TT/2},
    {0,TT/8},{H3,TT/8},{H5,TT/8},{H3,TT/16},{H2,TT/16},{H2,TT/4},{H3,TT/8},{H5,TT/16},{H3,TT/16},
    {3,TT/2},{H1,TT/16},{H2,TT/16},{H3,TT/16},{H5,TT/16},{H3,TT/16},{H2,TT/16},{H1,TT/16},{H6,TT/16},
    {H3,TT/4},{H6,TT/4},{H2,TT/4},{H3,TT/4},{H2,TT/4},
    {H2,TT/8},{H3,TT/8},{H5,TT/8},{H1,TT/8},{H1,TT/2},
    {M6,TT/8},{H5,TT/4},{H3,TT/8},{H1,TT/8},{H2,TT/8},{M6,TT/8},{H2,TT/16},{H1,TT/16},
    {H1,TT/1},
    {H1,TT/2},{0,TT/4},{0,TT/4},
    {0,TT/8},{M3,TT/8},{M2,TT/8},{M3,TT/8},{M5,TT/8},{M3,TT/16},{M2,TT/16},{M2,TT/4},
    {0,TT/8},{M2,TT/8},{M1,TT/8},{M2,TT/8},{M5,TT/8},{M2,TT/16},{M1,TT/16},{0,TT/8},{M5,TT/8},
    {M6,TT/8},{M5,TT/8},{M5,TT/8},{M3,TT/8},{M3,TT/8},{M2,TT/4},{M2,TT/8},
    {M2,TT/2},{0,TT/4},{M2,TT/8},{M1,TT/16},{M1,TT/16},
    {M1,TT/4},{M1,TT/2},{0,TT/4},
};
#endif
