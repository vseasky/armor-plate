#ifndef _MUSIC_TASK_H
#define _MUSIC_TASK_H
#include "bsp_tim.h"
#include "FreeRTOS.h"
#include "task.h"
#define BUZZER_HARDWARE_MAX_FREQ 7000000

void music_task_creat(void);
void musicPlay_task(void const *pvParameters);

#endif
